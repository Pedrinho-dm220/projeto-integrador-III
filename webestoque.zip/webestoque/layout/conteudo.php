<?php
$conteudo = '
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1 class="text-dark">Dashboard <small class="text-muted">Control panel</small></h1>
        <ol class="breadcrumb bg-transparent">
            <li><a href="#" class="text-dark"><i class="fa fa-home"></i> Home</a></li>
            <li class="active text-dark">Dashboard</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <!-- Small boxes (Stat box) -->
        <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-12 mb-3">
                <!-- small box -->
                <div class="small-box bg-info shadow-sm" style="border-radius: 15px;">
                    <div class="inner text-white">
                        <h3>150</h3>
                        <p>New Orders</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-bag"></i>
                    </div>
                    <a href="#" class="small-box-footer text-white">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 mb-3">
                <!-- small box -->
                <div class="small-box bg-success shadow-sm" style="border-radius: 15px;">
                    <div class="inner text-white">
                        <h3>53<sup style="font-size: 20px">%</sup></h3>
                        <p>Bounce Rate</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-stats-bars"></i>
                    </div>
                    <a href="#" class="small-box-footer text-white">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 mb-3">
                <!-- small box -->
                <div class="small-box bg-warning shadow-sm" style="border-radius: 15px;">
                    <div class="inner text-white">
                        <h3>44</h3>
                        <p>User Registrations</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-person-add"></i>
                    </div>
                    <a href="#" class="small-box-footer text-white">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 mb-3">
                <!-- small box -->
                <div class="small-box bg-danger shadow-sm" style="border-radius: 15px;">
                    <div class="inner text-white">
                        <h3>65</h3>
                        <p>Unique Visitors</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-pie-graph"></i>
                    </div>
                    <a href="#" class="small-box-footer text-white">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
        </div>

        <!-- Main row -->
        <div class="row">
            <!-- Left col -->
            <section class="col-lg-7 col-md-12 connectedSortable">
                <div class="nav-tabs-custom shadow-sm" style="border-radius: 15px;">
                    <ul class="nav nav-tabs pull-right">
                        <li class="active"><a href="#revenue-chart" data-toggle="tab">Area</a></li>
                        <li><a href="#sales-chart" data-toggle="tab">Donut</a></li>
                        <li class="pull-left header text-dark"><i class="fa fa-inbox"></i> Sales</li>
                    </ul>
                    <div class="tab-content no-padding">
                        <div class="chart tab-pane active" id="revenue-chart" style="position: relative; height: 300px;"></div>
                        <div class="chart tab-pane" id="sales-chart" style="position: relative; height: 300px;"></div>
                    </div>
                </div>

                <!-- Chat box -->
                <div class="box box-success shadow-sm" style="border-radius: 15px;">
                    <div class="box-header">
                        <i class="fa fa-comments-o"></i>
                        <h3 class="box-title">Chat</h3>
                    </div>
                    <div class="box-body chat" id="chat-box">
                        <div class="item">
                            <img src="dist/img/user4-128x128.jpg" alt="user image" class="online">
                            <p class="message">
                                <a href="#" class="name">Mike Doe <small class="text-muted pull-right"><i class="fa fa-clock-o"></i> 2:15</small></a>
                                I would like to meet you to discuss the latest news about the arrival of the new theme.
                            </p>
                        </div>
                    </div>
                    <div class="box-footer">
                        <div class="input-group">
                            <input class="form-control" placeholder="Type message...">
                            <div class="input-group-btn">
                                <button type="button" class="btn btn-success"><i class="fa fa-plus"></i></button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- To Do List -->
                <div class="box box-primary shadow-sm" style="border-radius: 15px;">
                    <div class="box-header">
                        <i class="ion ion-clipboard"></i>
                        <h3 class="box-title">To Do List</h3>
                    </div>
                    <div class="box-body">
                        <ul class="todo-list">
                            <li>
                                <span class="handle">
                                    <i class="fa fa-ellipsis-v"></i>
                                </span>
                                <input type="checkbox" value="">
                                <span class="text">Design a nice theme</span>
                                <small class="label label-danger"><i class="fa fa-clock-o"></i> 2 mins</small>
                            </li>
                        </ul>
                    </div>
                    <div class="box-footer clearfix no-border">
                        <button type="button" class="btn btn-default pull-right"><i class="fa fa-plus"></i> Add item</button>
                    </div>
                </div>
            </section>
            
            <!-- Right col -->
            <section class="col-lg-5 col-md-12 connectedSortable">
                <div class="box box-solid bg-light-blue-gradient shadow-sm" style="border-radius: 15px;">
                    <div class="box-header">
                        <i class="fa fa-map-marker"></i>
                        <h3 class="box-title">Visitors</h3>
                    </div>
                    <div class="box-body">
                        <div id="world-map" style="height: 250px; width: 100%;"></div>
                    </div>
                </div>

                <div class="box box-solid bg-teal-gradient shadow-sm" style="border-radius: 15px;">
                    <div class="box-header">
                        <i class="fa fa-th"></i>
                        <h3 class="box-title">Sales Graph</h3>
                    </div>
                    <div class="box-body">
                        <div class="chart" id="line-chart" style="height: 250px;"></div>
                    </div>
                </div>

                <div class="box box-solid bg-green-gradient shadow-sm" style="border-radius: 15px;">
                    <div class="box-header">
                        <i class="fa fa-calendar"></i>
                        <h3 class="box-title">Calendar</h3>
                    </div>
                    <div class="box-body no-padding">
                        <div id="calendar" style="width: 100%"></div>
                    </div>
                </div>
            </section>
        </div>
    </section>
</div>
';

echo $conteudo;
?>
