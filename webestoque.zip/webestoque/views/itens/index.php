<?php
require_once '../../App/auth.php';
require_once '../../layout/script.php';
require_once '../../App/Models/itens.class.php';

echo $head;
echo $header;
echo $aside;
echo '<div class="content-wrapper">
		<!-- Content Header (Page header) -->
    <section class="content-header">
      <h1 style="font-family: \'Poppins\', sans-serif;">
        Itens Cadastrados
      </h1>
      <ol class="breadcrumb">
        <li><a href="../"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Itens</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
    ';
    require '../../layout/alert.php';
    echo '
      <!-- Small boxes (Stat box) -->
      <div class="row">
      	<div class="box" style="border-radius: 8px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
            <div class="box-header" style="background-color: #f5f5f5; border-bottom: 2px solid #ddd; padding: 20px;">
              <i class="ion ion-clipboard" style="font-size: 24px; color: #007bff;"></i>
              <h3 class="box-title" style="font-family: \'Poppins\', sans-serif; font-weight: 600;">Lista de Itens</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body" style="font-family: \'Roboto\', sans-serif; padding: 20px; background-color: #fff;">';

        if(isset($_POST['public']) != NULL){               

          $value = $_POST['public']; 
          if($value == 1){
            $public = 0;
            $button_name = "Inativos";

          }else{
            $public = 1;
            $button_name = "Publicados";
          }     

        }else{
          $value = 1;
          $public = 0;
          $button_name = "Inativos";
        }

               $itens->index($value);
              
        echo ' </div>
            <!-- /.box-body -->
           
            <div class="box-footer clearfix no-border" style="border-top: 2px solid #ddd; padding: 15px; background-color: #f5f5f5;">
             <form action="index.php" method="post">
         <button name="public" type="submit" value="'.$public.'" class="btn btn-outline-info" style="font-family: \'Poppins\', sans-serif; padding: 10px 20px; border-radius: 5px; margin-right: 10px; border: 2px solid #17a2b8; transition: all 0.3s ease;">
             <i class="fa fa-plus"></i> '.$button_name.'</button></form>
              <a href="additens.php" type="button" class="btn btn-success pull-right" style="font-family: \'Poppins\', sans-serif; padding: 10px 20px; border-radius: 5px; border: none; transition: background-color 0.3s ease;">
                  <i class="fa fa-plus"></i> Adicionar Itens
              </a>
            </div>
          </div>
	 
';
echo '</div>';
echo '</section>';          	  

echo '</div>';

echo  $footer;
echo $javascript;
?>

<!-- Estilos Personalizados -->
<style>
/* Estilos para Botões */
.btn-outline-info {
  background-color: transparent;
  color: #17a2b8;
  border-color: #17a2b8;
  transition: all 0.3s ease;
}

.btn-outline-info:hover {
  background-color: #17a2b8;
  color: #fff;
}

.btn-success {
  background-color: #28a745;
  border-color: #28a745;
  transition: background-color 0.3s ease;
}

.btn-success:hover {
  background-color: #218838;
}

/* Caixa de Texto */
.box-header, .box-footer {
  border-radius: 8px;
}

.box-body {
  background-color: #fff;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  padding: 20px;
}

h3.box-title {
  font-family: 'Poppins', sans-serif;
  font-weight: 600;
  font-size: 24px;
}

/* Fontes Modernas */
body, h1, h2, h3, h4, h5, h6 {
  font-family: 'Roboto', sans-serif;
}

/* Estilos da Breadcrumb */
.breadcrumb {
  font-family: 'Roboto', sans-serif;
  font-size: 14px;
  background-color: #f8f9fa;
}

.breadcrumb a {
  color: #007bff;
}

.breadcrumb .active {
  color: #6c757d;
}
</style>

<!-- Adicionando fontes do Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&family=Roboto:wght@400&display=swap" rel="stylesheet">
