<?php
require_once '../App/auth.php';
require_once '../layout/script.php';
require_once '../App/Models/relatorios.class.php';

echo $head;
echo $header;
echo $aside;
echo '<div class="content-wrapper">';

echo '<section class="content" style="height: auto !important; min-height: 0px !important;">
';

echo '
<style>
  /* Fonte geral para o corpo */
  body {
    font-family: "Roboto", sans-serif;
    background-color: #f4f6f9;
  }

  /* Estilos para os títulos e textos das caixas */
  .small-box .inner h3, .small-box .inner p {
    font-family: "Roboto", sans-serif;
    color: #333;
  }

  /* Estilo para o footer das caixas */
  .small-box-footer {
    font-family: "Roboto", sans-serif;
    color: #666;
  }

  /* Estilo das caixas com cores neutras */
  .small-box {
    border-radius: 10px;
    padding: 20px;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
  }

  /* Estilos neutros para as caixas */
  .bg-light-gray { background-color: #d3d3d3; }
  .bg-gray { background-color: #a9a9a9; }
  .bg-muted-blue { background-color: #b0c4de; }
  .bg-muted-green { background-color: #98fb98; }

  .small-box:hover {
    transform: scale(1.05);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
  }

  /* Responsividade para as caixas */
  @media (max-width: 767px) {
    .small-box {
      margin-bottom: 15px;
    }
  }
</style>
';

if ($perm == 1) {
  echo '
      <!-- Small boxes (Stat box) -->     
      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-light-gray">
            <div class="inner">
              <h3>150</h3>
              <p>Novas Ordens</p>
            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            <a href="#" class="small-box-footer">Mais informações <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-gray">
            <div class="inner">
              <h3>';
              $relatorio = new Relatorio();
              $r = $relatorio->qtdeItensEstoqueTotal($perm);
              echo $r;
              echo '</h3>
              <p>Quantidade em Estoque</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <a href="#" class="small-box-footer">Mais informações <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-muted-blue">
            <div class="inner">
              <h3>44</h3>
              <p>Registro de Usuários</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="#" class="small-box-footer">Mais informações <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-muted-green">
            <div class="inner">
              <h3>65</h3>
              <p>Visitantes Únicos</p>
            </div>
            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
            <a href="#" class="small-box-footer">Mais informações <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
      </div>
      <!-- /.row -->';
}

echo '
      <!-- Main row -->
      <div class="row">
        <!-- Content goes here -->
      </div>
      </div>
    </section>
</div>
';

echo  $footer;
echo $javascript;
?>
