<?php
// Lógica de cadastro PHP no topo da página
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_username'], $_POST['new_password'], $_POST['email'])) {
    $host = 'localhost';
    $user = 'root';
    $pass = '';
    $db = 'controle_estoque';

    $conn = new mysqli($host, $user, $pass, $db);
    if ($conn->connect_error) {
        die("Erro de conexão: " . $conn->connect_error);
    }

    $username = trim($_POST['new_username']);
    $password = trim($_POST['new_password']);
    $email = trim($_POST['email']);

    if ($username === '' || $password === '' || $email === '') {
        header("Location: login.php?erro=campos_vazios");
        exit;
    }

    $check = $conn->prepare("SELECT id FROM usuarios WHERE username = ?");
    $check->bind_param("s", $username);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        $check->close();
        $conn->close();
        header("Location: login.php?erro=usuario_ja_existe");
        exit;
    }

    $check->close();
    $senhaHash = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO usuarios (username, password, email) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $username, $senhaHash, $email);

    if ($stmt->execute()) {
        $stmt->close();
        $conn->close();
        header("Location: login.php?sucesso=1");
        exit;
    } else {
        $stmt->close();
        $conn->close();
        header("Location: login.php?erro=erro_banco");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Controle de Estoque | Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="views/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="views/plugins/iCheck/square/blue.css">
  <link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Lato', sans-serif;
      background: #f0f2f5;
      display: flex;
      justify-content: center;
      padding: 60px 15px;
    }
    .login-box {
      width: 300px;
      background-color: #fff;
      border-radius: 10px;
      padding: 25px;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }
    .login-logo {
      text-align: center;
      margin-bottom: 15px;
    }
    .login-logo a {
      color: #C05B65;
      font-weight: bold;
      text-decoration: none;
      font-size: 18px;
    }
    .login-box-msg {
      text-align: center;
      color: #444;
      font-size: 14px;
      margin-bottom: 15px;
    }
    .form-input {
      width: 100%;
      height: 40px;
      border: 1px solid #ccc;
      border-radius: 6px;
      padding: 8px 10px;
      margin-bottom: 12px;
      font-size: 14px;
      background: #fafafa;
    }
    .form-btn {
      width: 100%;
      height: 40px;
      background-color: #C05B65;
      border: none;
      border-radius: 6px;
      color: #fff;
      font-size: 15px;
      cursor: pointer;
      transition: background 0.3s ease;
    }
    .form-btn:hover {
      background-color: #a94d57;
    }
    .checkbox label {
      font-size: 13px;
      color: #555;
    }
    .alert {
      font-size: 13px;
      padding: 10px;
      margin-bottom: 15px;
      text-align: center;
    }
    @media screen and (max-width: 400px) {
      .login-box {
        width: 100%;
      }
    }
  </style>
</head>
<body>
  <div class="login-box">
    <div class="login-logo">
      <a href="#"><b>Controle de Estoque</b></a>
    </div>

    <!-- Mensagens -->
    <?php if (isset($_GET['sucesso'])): ?>
      <div class="alert alert-success">Usuário cadastrado com sucesso!</div>
    <?php elseif (isset($_GET['erro']) && $_GET['erro'] === 'usuario_ja_existe'): ?>
      <div class="alert alert-danger">Usuário já existe.</div>
    <?php elseif (isset($_GET['erro']) && $_GET['erro'] === 'campos_vazios'): ?>
      <div class="alert alert-warning">Preencha todos os campos.</div>
    <?php elseif (isset($_GET['erro']) && $_GET['erro'] === 'login_invalido'): ?>
      <div class="alert alert-danger">Login inválido. Verifique seus dados.</div>
    <?php elseif (isset($_GET['erro']) && $_GET['erro'] === 'erro_banco'): ?>
      <div class="alert alert-danger">Erro ao cadastrar. Tente novamente.</div>
    <?php endif; ?>

    <p class="login-box-msg">Faça o login para iniciar sua sessão</p>

    <form action="App/session.php" method="post">
      <input type="text" name="username" class="form-input" placeholder="Nome de usuário" required>
      <input type="password" name="password" class="form-input" placeholder="Senha" required>
      <div class="checkbox" style="margin-bottom: 12px;">
        <label><input type="checkbox" name="remember"> Lembrar-me</label>
      </div>
      <button type="submit" class="form-btn">Entrar</button>
    </form>

    <hr>

    <p class="login-box-msg">Não tem uma conta? Cadastre-se abaixo:</p>

    <!-- Cadastro direto na mesma página -->
    <form action="" method="post">
      <input type="text" name="new_username" class="form-input" placeholder="Novo usuário" required>
      <input type="password" name="new_password" class="form-input" placeholder="Nova senha" required>
      <input type="email" name="email" class="form-input" placeholder="Email" required>
      <button type="submit" class="form-btn">Cadastrar</button>
    </form>
  </div>

  <!-- Scripts -->
  <script src="views/plugins/jQuery/jquery-2.2.3.min.js"></script>
  <script src="views/bootstrap/js/bootstrap.min.js"></script>
  <script src="views/plugins/iCheck/icheck.min.js"></script>
  <script>
    $(function () {
      $('input').iCheck({
        checkboxClass: 'icheckbox_square-blue',
        radioClass: 'iradio_square-blue',
        increaseArea: '20%'
      });
    });
  </script>
</body>
</html>
